# Finance Tracker Application

A full-stack personal finance management application built with Flask (Python) backend and React frontend.

## Features

- User authentication and authorization
- Transaction tracking and categorization
- Budget management
- Dashboard with financial insights
- Persistent PostgreSQL database

## Architecture

- **Backend**: Flask REST API with PostgreSQL database
- **Frontend**: React single-page application served by Nginx
- **Database**: PostgreSQL 15
- **Containerization**: Docker & Docker Compose

## Prerequisites

- [Docker](https://docs.docker.com/get-docker/) (version 20.10 or higher)
- [Docker Compose](https://docs.docker.com/compose/install/) (version 2.0 or higher)

## Quick Start

### 1. Clone and Navigate to Project

```bash
cd finance-tracker
```

### 2. Build and Start All Services

```bash
docker-compose up --build
```

This single command will:
- Build the backend and frontend Docker images
- Start the PostgreSQL database
- Run database migrations
- Launch all services

### 3. Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **Database**: localhost:5432 (postgres/postgres)

## Available Commands

### Start Services (Detached Mode)

```bash
docker-compose up -d
```

### Stop Services

```bash
docker-compose down
```

### Stop and Remove All Data (Reset Database)

```bash
docker-compose down -v
```

**Warning**: This will delete all database data!

### View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f db
```

### Rebuild After Code Changes

```bash
docker-compose up --build
```

### Access Backend Shell

```bash
docker-compose exec backend bash
```

### Access Database

```bash
docker-compose exec db psql -U postgres -d finance_tracker
```

## Project Structure

```
finance-tracker/
├── backend/              # Flask backend application
│   ├── app/             # Application code
│   ├── migrations/      # Database migrations
│   ├── Dockerfile       # Backend container configuration
│   ├── entrypoint.sh    # Startup script
│   └── requirements.txt # Python dependencies
├── frontend/            # React frontend application
│   ├── src/            # React source code
│   ├── public/         # Static assets
│   ├── Dockerfile      # Frontend container configuration
│   └── nginx.conf      # Nginx configuration
├── docker-compose.yml  # Multi-container orchestration
└── .env               # Environment variables
```

## Environment Variables

Configuration is managed through `.env` file. **Important**: Change default values in production!

Key variables:
- `DATABASE_URL`: PostgreSQL connection string
- `JWT_SECRET_KEY`: Secret key for JWT tokens (change in production!)
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`: Database credentials

## Development vs Production

### Development
The current setup is suitable for development with hot-reloading capabilities.

### Production Considerations
Before deploying to production:

1. **Change security credentials**:
   ```bash
   # Generate secure JWT secret
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

2. **Update environment variables** in `.env`

3. **Use proper secrets management** (AWS Secrets Manager, HashiCorp Vault, etc.)

4. **Configure HTTPS** with proper SSL certificates

5. **Set appropriate CORS policies**

6. **Enable additional security headers** in Nginx

7. **Configure database backups**

## Troubleshooting

### Database Connection Issues

If backend fails to connect to database:
```bash
docker-compose logs db
docker-compose restart backend
```

### Port Already in Use

If ports 3000, 5000, or 5432 are already in use, modify the port mappings in `docker-compose.yml`:

```yaml
ports:
  - "3001:80"  # Change 3000 to 3001 for frontend
```

### Reset Everything

To start fresh:
```bash
docker-compose down -v
docker system prune -a
docker-compose up --build
```

## Support

For issues or questions, please check the application logs:
```bash
docker-compose logs -f
```

## License

[Add your license here]
