#!/bin/bash

# Exit on error
set -e

echo "Waiting for PostgreSQL to be ready..."

# Wait for PostgreSQL to be available
until pg_isready -h db -U postgres; do
  echo "PostgreSQL is unavailable - sleeping"
  sleep 2
done

echo "PostgreSQL is up - continuing"

# Run database migrations
echo "Running database migrations..."
flask db upgrade

echo "Starting Gunicorn server..."

# Start Gunicorn
exec gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 120 'app:create_app()'
