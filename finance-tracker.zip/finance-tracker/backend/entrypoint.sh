#!/bin/bash

set -e

echo "Waiting for PostgreSQL to be ready..."

until pg_isready -h db -U postgres; do
  echo "PostgreSQL is unavailable - sleeping"
  sleep 2
done

echo "PostgreSQL is up - continuing"

# Create tables directly (no migrations needed)
echo "Creating database tables..."
python -c "from app import create_app, db; app = create_app(); app.app_context().push()"

echo "Starting Gunicorn server..."

exec gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 120 'app:create_app()'
