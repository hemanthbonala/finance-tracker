from datetime import datetime
from app import db


class Transaction(db.Model):
    """Transaction model for income and expense records."""
    __tablename__ = 'transactions'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    type = db.Column(db.String(10), nullable=False)  # 'income' or 'expense'
    note = db.Column(db.String(255), nullable=True)
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # Indexes and constraints
    __table_args__ = (
        db.Index('idx_transaction_user_date', 'user_id', 'date'),
        db.Index('idx_transaction_user_category', 'user_id', 'category_id'),
        db.CheckConstraint('amount > 0', name='check_amount_positive'),
    )

    def __repr__(self):
        return f'<Transaction {self.type} {self.amount} on {self.date}>'
