from datetime import datetime
from app import db


class Budget(db.Model):
    """Budget model for setting spending limits per category."""
    __tablename__ = 'budgets'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    amount_limit = db.Column(db.Numeric(10, 2), nullable=False)
    month = db.Column(db.Integer, nullable=False)  # 1-12
    year = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # Indexes and constraints
    __table_args__ = (
        db.UniqueConstraint('user_id', 'category_id', 'month', 'year',
                          name='uq_user_category_month_year'),
        db.CheckConstraint('month >= 1 AND month <= 12', name='check_month_range'),
        db.CheckConstraint('amount_limit > 0', name='check_amount_limit_positive'),
    )

    def __repr__(self):
        return f'<Budget {self.amount_limit} for {self.month}/{self.year}>'
