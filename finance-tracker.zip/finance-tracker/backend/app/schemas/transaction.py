from marshmallow import Schema, fields, validate


class TransactionCreateSchema(Schema):
    """Schema for creating transactions."""
    amount = fields.Decimal(required=True, as_string=True, places=2, validate=validate.Range(min=0.01))
    type = fields.String(required=True, validate=validate.OneOf(['income', 'expense']))
    category_id = fields.Integer(required=True)
    note = fields.String(validate=validate.Length(max=255), allow_none=True)
    date = fields.Date(required=True)


class TransactionUpdateSchema(Schema):
    """Schema for updating transactions (all fields optional)."""
    amount = fields.Decimal(as_string=True, places=2, validate=validate.Range(min=0.01))
    type = fields.String(validate=validate.OneOf(['income', 'expense']))
    category_id = fields.Integer()
    note = fields.String(validate=validate.Length(max=255), allow_none=True)
    date = fields.Date()


class CategoryNestedSchema(Schema):
    """Nested schema for category in transaction response."""
    id = fields.Integer()
    name = fields.String()
    type = fields.String()
    icon = fields.String()
    color = fields.String()


class TransactionResponseSchema(Schema):
    """Schema for transaction response."""
    id = fields.Integer(dump_only=True)
    amount = fields.Decimal(as_string=True, places=2)
    type = fields.String()
    note = fields.String()
    date = fields.Date()
    category = fields.Nested(CategoryNestedSchema)
    created_at = fields.DateTime(dump_only=True)
