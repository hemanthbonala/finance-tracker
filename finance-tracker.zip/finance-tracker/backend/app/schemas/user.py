from marshmallow import Schema, fields, validate


class UserRegisterSchema(Schema):
    """Schema for user registration."""
    name = fields.String(required=True, validate=validate.Length(min=1, max=100))
    email = fields.Email(required=True)
    password = fields.String(required=True, validate=validate.Length(min=6), load_only=True)


class UserResponseSchema(Schema):
    """Schema for user response (excludes password)."""
    id = fields.Integer(dump_only=True)
    name = fields.String()
    email = fields.Email()
    created_at = fields.DateTime(dump_only=True)
