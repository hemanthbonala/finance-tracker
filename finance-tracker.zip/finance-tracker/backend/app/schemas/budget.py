from marshmallow import Schema, fields, validate


class BudgetCreateSchema(Schema):
    """Schema for creating/updating budgets."""
    category_id = fields.Integer(required=True)
    amount_limit = fields.Decimal(required=True, as_string=True, places=2,
                                  validate=validate.Range(min=0.01))
    month = fields.Integer(required=True, validate=validate.Range(min=1, max=12))
    year = fields.Integer(required=True, validate=validate.Range(min=2000, max=2100))


class BudgetResponseSchema(Schema):
    """Schema for budget response."""
    id = fields.Integer(dump_only=True)
    category_id = fields.Integer()
    amount_limit = fields.Decimal(as_string=True, places=2)
    month = fields.Integer()
    year = fields.Integer()
    created_at = fields.DateTime(dump_only=True)
