from marshmallow import Schema, fields, validate


class CategoryCreateSchema(Schema):
    """Schema for creating/updating categories."""
    name = fields.String(required=True, validate=validate.Length(min=1, max=50))
    type = fields.String(required=True, validate=validate.OneOf(['income', 'expense']))
    icon = fields.String(validate=validate.Length(max=10), allow_none=True)
    color = fields.String(validate=validate.Length(max=7), allow_none=True)


class CategoryResponseSchema(Schema):
    """Schema for category response."""
    id = fields.Integer(dump_only=True)
    name = fields.String()
    type = fields.String()
    icon = fields.String()
    color = fields.String()
    created_at = fields.DateTime(dump_only=True)
