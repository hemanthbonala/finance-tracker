from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from marshmallow import ValidationError
from app import db
from app.models.category import Category
from app.models.transaction import Transaction
from app.schemas.category import CategoryCreateSchema, CategoryResponseSchema

categories_bp = Blueprint('categories', __name__)

category_create_schema = CategoryCreateSchema()
category_response_schema = CategoryResponseSchema()
categories_response_schema = CategoryResponseSchema(many=True)


@categories_bp.route('/', methods=['GET'])
@jwt_required()
def get_categories():
    """Get all categories for the current user."""
    user_id = get_jwt_identity()
    categories = Category.query.filter_by(user_id=user_id).order_by(Category.name).all()

    return jsonify({'categories': categories_response_schema.dump(categories)}), 200


@categories_bp.route('/', methods=['POST'])
@jwt_required()
def create_category():
    """Create a new category for the current user."""
    user_id = get_jwt_identity()

    try:
        data = category_create_schema.load(request.get_json())
    except ValidationError as err:
        return jsonify({'error': 'Validation failed', 'messages': err.messages}), 400

    # Check if category name already exists for this user
    existing = Category.query.filter_by(user_id=user_id, name=data['name']).first()
    if existing:
        return jsonify({'error': 'Category name already exists'}), 409

    try:
        category = Category(
            user_id=user_id,
            name=data['name'],
            type=data['type'],
            icon=data.get('icon'),
            color=data.get('color')
        )

        db.session.add(category)
        db.session.commit()

        return jsonify({
            'message': 'Category created successfully',
            'category': category_response_schema.dump(category)
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create category', 'message': str(e)}), 500


@categories_bp.route('/<int:category_id>', methods=['PUT'])
@jwt_required()
def update_category(category_id):
    """Update a category (only if it belongs to the current user)."""
    user_id = get_jwt_identity()

    category = Category.query.filter_by(id=category_id, user_id=user_id).first()
    if not category:
        return jsonify({'error': 'Category not found'}), 404

    try:
        data = category_create_schema.load(request.get_json(), partial=True)
    except ValidationError as err:
        return jsonify({'error': 'Validation failed', 'messages': err.messages}), 400

    # Check if new name conflicts with existing category
    if 'name' in data and data['name'] != category.name:
        existing = Category.query.filter_by(user_id=user_id, name=data['name']).first()
        if existing:
            return jsonify({'error': 'Category name already exists'}), 409

    try:
        if 'name' in data:
            category.name = data['name']
        if 'type' in data:
            category.type = data['type']
        if 'icon' in data:
            category.icon = data['icon']
        if 'color' in data:
            category.color = data['color']

        db.session.commit()

        return jsonify({
            'message': 'Category updated successfully',
            'category': category_response_schema.dump(category)
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to update category', 'message': str(e)}), 500


@categories_bp.route('/<int:category_id>', methods=['DELETE'])
@jwt_required()
def delete_category(category_id):
    """Delete a category (only if it belongs to the current user and has no transactions)."""
    user_id = get_jwt_identity()

    category = Category.query.filter_by(id=category_id, user_id=user_id).first()
    if not category:
        return jsonify({'error': 'Category not found'}), 404

    # Check if category has transactions
    transaction_count = Transaction.query.filter_by(category_id=category_id).count()
    if transaction_count > 0:
        return jsonify({
            'error': 'Cannot delete category with existing transactions',
            'transaction_count': transaction_count
        }), 409

    try:
        db.session.delete(category)
        db.session.commit()

        return jsonify({'message': 'Category deleted successfully'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to delete category', 'message': str(e)}), 500
