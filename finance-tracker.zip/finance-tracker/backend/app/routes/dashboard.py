from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import extract, func
from datetime import datetime
from app import db
from app.models.transaction import Transaction
from app.models.category import Category
from app.models.budget import Budget

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/', methods=['GET'])
@jwt_required()
def get_dashboard():
    """Get dashboard data for the current month (or specified month/year)."""
    user_id = get_jwt_identity()

    # Get month and year from query params or use current
    month = request.args.get('month', type=int, default=datetime.now().month)
    year = request.args.get('year', type=int, default=datetime.now().year)

    if month < 1 or month > 12:
        return jsonify({'error': 'Month must be between 1 and 12'}), 400

    # Calculate total income
    total_income = db.session.query(func.sum(Transaction.amount)).filter(
        Transaction.user_id == user_id,
        Transaction.type == 'income',
        extract('month', Transaction.date) == month,
        extract('year', Transaction.date) == year
    ).scalar() or 0

    # Calculate total expenses
    total_expenses = db.session.query(func.sum(Transaction.amount)).filter(
        Transaction.user_id == user_id,
        Transaction.type == 'expense',
        extract('month', Transaction.date) == month,
        extract('year', Transaction.date) == year
    ).scalar() or 0

    # Calculate savings
    savings = float(total_income) - float(total_expenses)

    # Calculate savings rate
    savings_rate = (savings / float(total_income) * 100) if total_income > 0 else 0

    # Category breakdown (expenses by category)
    category_breakdown = db.session.query(
        Category.name,
        Category.color,
        func.sum(Transaction.amount).label('total')
    ).join(
        Transaction, Transaction.category_id == Category.id
    ).filter(
        Transaction.user_id == user_id,
        Transaction.type == 'expense',
        extract('month', Transaction.date) == month,
        extract('year', Transaction.date) == year
    ).group_by(Category.id, Category.name, Category.color).all()

    category_breakdown_list = [
        {
            'category_name': name,
            'category_color': color,
            'total_spent': str(total)
        }
        for name, color, total in category_breakdown
    ]

    # Budget status
    budgets = Budget.query.filter_by(user_id=user_id, month=month, year=year).all()

    budget_status = []
    for budget in budgets:
        category = Category.query.get(budget.category_id)

        # Calculate spent amount for this budget
        spent = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.category_id == budget.category_id,
            Transaction.type == 'expense',
            extract('month', Transaction.date) == month,
            extract('year', Transaction.date) == year
        ).scalar() or 0

        percentage = float(spent / budget.amount_limit * 100) if budget.amount_limit > 0 else 0

        # Determine status
        if percentage >= 100:
            status = 'over'
        elif percentage >= 80:
            status = 'warning'
        else:
            status = 'safe'

        budget_status.append({
            'category_name': category.name if category else 'Unknown',
            'limit': str(budget.amount_limit),
            'spent': str(spent),
            'percentage': round(percentage, 2),
            'status': status
        })

    # Recent transactions (last 5)
    recent_transactions = Transaction.query.filter(
        Transaction.user_id == user_id,
        extract('month', Transaction.date) == month,
        extract('year', Transaction.date) == year
    ).order_by(Transaction.date.desc(), Transaction.created_at.desc()).limit(5).all()

    recent_transactions_list = []
    for trans in recent_transactions:
        category = Category.query.get(trans.category_id)
        recent_transactions_list.append({
            'id': trans.id,
            'amount': str(trans.amount),
            'type': trans.type,
            'category_name': category.name if category else 'Unknown',
            'note': trans.note,
            'date': trans.date.isoformat()
        })

    return jsonify({
        'month': month,
        'year': year,
        'total_income': str(total_income),
        'total_expenses': str(total_expenses),
        'savings': str(savings),
        'savings_rate': round(savings_rate, 2),
        'category_breakdown': category_breakdown_list,
        'budget_status': budget_status,
        'recent_transactions': recent_transactions_list
    }), 200
