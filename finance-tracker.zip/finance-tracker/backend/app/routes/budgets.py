from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from marshmallow import ValidationError
from sqlalchemy import extract, func
from app import db
from app.models.budget import Budget
from app.models.category import Category
from app.models.transaction import Transaction
from app.schemas.budget import BudgetCreateSchema, BudgetResponseSchema

budgets_bp = Blueprint('budgets', __name__)

budget_create_schema = BudgetCreateSchema()
budget_response_schema = BudgetResponseSchema()
budgets_response_schema = BudgetResponseSchema(many=True)


@budgets_bp.route('/', methods=['GET'])
@jwt_required()
def get_budgets():
    """Get budgets for a given month/year with spent amounts."""
    user_id = get_jwt_identity()

    month = request.args.get('month', type=int)
    year = request.args.get('year', type=int)

    if not month or not year:
        return jsonify({'error': 'Month and year are required'}), 400

    if month < 1 or month > 12:
        return jsonify({'error': 'Month must be between 1 and 12'}), 400

    # Get budgets for the specified month/year
    budgets = Budget.query.filter_by(user_id=user_id, month=month, year=year).all()

    # Calculate spent amount for each budget
    result = []
    for budget in budgets:
        # Sum transactions for this category in the specified month/year
        spent = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user_id,
            Transaction.category_id == budget.category_id,
            Transaction.type == 'expense',
            extract('month', Transaction.date) == month,
            extract('year', Transaction.date) == year
        ).scalar() or 0

        budget_data = budget_response_schema.dump(budget)
        budget_data['spent'] = str(spent)
        budget_data['remaining'] = str(budget.amount_limit - spent)
        budget_data['percentage'] = float(spent / budget.amount_limit * 100) if budget.amount_limit > 0 else 0

        result.append(budget_data)

    return jsonify({'budgets': result}), 200


@budgets_bp.route('/', methods=['POST'])
@jwt_required()
def create_or_update_budget():
    """Create or update a budget (upsert)."""
    user_id = get_jwt_identity()

    try:
        data = budget_create_schema.load(request.get_json())
    except ValidationError as err:
        return jsonify({'error': 'Validation failed', 'messages': err.messages}), 400

    # Verify category belongs to user
    category = Category.query.filter_by(id=data['category_id'], user_id=user_id).first()
    if not category:
        return jsonify({'error': 'Category not found or does not belong to user'}), 404

    # Check if budget already exists for this category/month/year
    existing_budget = Budget.query.filter_by(
        user_id=user_id,
        category_id=data['category_id'],
        month=data['month'],
        year=data['year']
    ).first()

    try:
        if existing_budget:
            # Update existing budget
            existing_budget.amount_limit = data['amount_limit']
            db.session.commit()

            return jsonify({
                'message': 'Budget updated successfully',
                'budget': budget_response_schema.dump(existing_budget)
            }), 200
        else:
            # Create new budget
            budget = Budget(
                user_id=user_id,
                category_id=data['category_id'],
                amount_limit=data['amount_limit'],
                month=data['month'],
                year=data['year']
            )

            db.session.add(budget)
            db.session.commit()

            return jsonify({
                'message': 'Budget created successfully',
                'budget': budget_response_schema.dump(budget)
            }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to save budget', 'message': str(e)}), 500


@budgets_bp.route('/<int:budget_id>', methods=['DELETE'])
@jwt_required()
def delete_budget(budget_id):
    """Delete a budget (only if it belongs to the current user)."""
    user_id = get_jwt_identity()

    budget = Budget.query.filter_by(id=budget_id, user_id=user_id).first()
    if not budget:
        return jsonify({'error': 'Budget not found'}), 404

    try:
        db.session.delete(budget)
        db.session.commit()

        return jsonify({'message': 'Budget deleted successfully'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to delete budget', 'message': str(e)}), 500
