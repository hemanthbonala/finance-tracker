from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from marshmallow import ValidationError
from sqlalchemy import extract
from app import db
from app.models.transaction import Transaction
from app.models.category import Category
from app.schemas.transaction import (
    TransactionCreateSchema,
    TransactionUpdateSchema,
    TransactionResponseSchema
)

transactions_bp = Blueprint('transactions', __name__)

transaction_create_schema = TransactionCreateSchema()
transaction_update_schema = TransactionUpdateSchema()
transaction_response_schema = TransactionResponseSchema()
transactions_response_schema = TransactionResponseSchema(many=True)


@transactions_bp.route('/', methods=['GET'])
@jwt_required()
def get_transactions():
    """Get all transactions for the current user with optional filters."""
    user_id = get_jwt_identity()

    # Build query
    query = Transaction.query.filter_by(user_id=user_id)

    # Apply filters
    month = request.args.get('month', type=int)
    year = request.args.get('year', type=int)
    category_id = request.args.get('category_id', type=int)
    transaction_type = request.args.get('type')

    if month:
        query = query.filter(extract('month', Transaction.date) == month)
    if year:
        query = query.filter(extract('year', Transaction.date) == year)
    if category_id:
        query = query.filter_by(category_id=category_id)
    if transaction_type:
        query = query.filter_by(type=transaction_type)

    # Order by date descending
    transactions = query.order_by(Transaction.date.desc()).all()

    return jsonify({'transactions': transactions_response_schema.dump(transactions)}), 200


@transactions_bp.route('/', methods=['POST'])
@jwt_required()
def create_transaction():
    """Create a new transaction for the current user."""
    user_id = get_jwt_identity()

    try:
        data = transaction_create_schema.load(request.get_json())
    except ValidationError as err:
        return jsonify({'error': 'Validation failed', 'messages': err.messages}), 400

    # Verify that category belongs to user
    category = Category.query.filter_by(id=data['category_id'], user_id=user_id).first()
    if not category:
        return jsonify({'error': 'Category not found or does not belong to user'}), 404

    try:
        transaction = Transaction(
            user_id=user_id,
            category_id=data['category_id'],
            amount=data['amount'],
            type=data['type'],
            note=data.get('note'),
            date=data['date']
        )

        db.session.add(transaction)
        db.session.commit()

        return jsonify({
            'message': 'Transaction created successfully',
            'transaction': transaction_response_schema.dump(transaction)
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to create transaction', 'message': str(e)}), 500


@transactions_bp.route('/<int:transaction_id>', methods=['PUT'])
@jwt_required()
def update_transaction(transaction_id):
    """Update a transaction (only if it belongs to the current user)."""
    user_id = get_jwt_identity()

    transaction = Transaction.query.filter_by(id=transaction_id, user_id=user_id).first()
    if not transaction:
        return jsonify({'error': 'Transaction not found'}), 404

    try:
        data = transaction_update_schema.load(request.get_json())
    except ValidationError as err:
        return jsonify({'error': 'Validation failed', 'messages': err.messages}), 400

    # Verify category belongs to user if being updated
    if 'category_id' in data:
        category = Category.query.filter_by(id=data['category_id'], user_id=user_id).first()
        if not category:
            return jsonify({'error': 'Category not found or does not belong to user'}), 404

    try:
        if 'amount' in data:
            transaction.amount = data['amount']
        if 'type' in data:
            transaction.type = data['type']
        if 'category_id' in data:
            transaction.category_id = data['category_id']
        if 'note' in data:
            transaction.note = data['note']
        if 'date' in data:
            transaction.date = data['date']

        db.session.commit()

        return jsonify({
            'message': 'Transaction updated successfully',
            'transaction': transaction_response_schema.dump(transaction)
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to update transaction', 'message': str(e)}), 500


@transactions_bp.route('/<int:transaction_id>', methods=['DELETE'])
@jwt_required()
def delete_transaction(transaction_id):
    """Delete a transaction (only if it belongs to the current user)."""
    user_id = get_jwt_identity()

    transaction = Transaction.query.filter_by(id=transaction_id, user_id=user_id).first()
    if not transaction:
        return jsonify({'error': 'Transaction not found'}), 404

    try:
        db.session.delete(transaction)
        db.session.commit()

        return jsonify({'message': 'Transaction deleted successfully'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to delete transaction', 'message': str(e)}), 500
