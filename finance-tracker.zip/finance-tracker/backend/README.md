# Finance Tracker Backend

A comprehensive Flask REST API backend for a personal finance tracking application with user authentication, transaction management, budgeting, and dashboard analytics.

## Features

- User authentication with JWT tokens
- Category management (income/expense)
- Transaction tracking with filtering
- Budget management with spending alerts
- Dashboard with financial analytics
- PostgreSQL database with proper indexes and constraints
- Full input validation with Marshmallow schemas
- Proper error handling with JSON responses

## Tech Stack

- **Python 3.9+**
- **Flask** - Web framework
- **SQLAlchemy** - ORM
- **PostgreSQL** - Database
- **Flask-JWT-Extended** - JWT authentication
- **Marshmallow** - Data validation and serialization
- **Flask-Migrate** - Database migrations

## Prerequisites

- Python 3.9 or higher
- PostgreSQL 12 or higher
- pip (Python package manager)

## Setup Instructions

### 1. Clone and Navigate to Backend Directory

```bash
cd finance-tracker/backend
```

### 2. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Create PostgreSQL Database

```bash
# Login to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE finance_tracker;

# Exit psql
\q
```

### 5. Configure Environment Variables

Create a `.env` file in the backend directory:

```env
DATABASE_URL=postgresql://postgres:password@localhost:5432/finance_tracker
JWT_SECRET_KEY=your-secret-key-change-this-in-production
FLASK_ENV=development
```

**Note:** Change `password` to your PostgreSQL password and generate a secure JWT secret key for production.

### 6. Initialize Database

```bash
# Initialize migrations (first time only)
flask db init

# Create initial migration
flask db migrate -m "Initial migration"

# Apply migrations
flask db upgrade
```

### 7. Run the Application

```bash
python run.py
```

The API will be available at `http://localhost:5000`

## Database Schema Migration Commands

```bash
# Create a new migration after model changes
flask db migrate -m "Description of changes"

# Apply pending migrations
flask db upgrade

# Revert last migration
flask db downgrade

# View migration history
flask db history
```

## API Documentation

### Authentication Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/auth/register` | Register new user | No |
| POST | `/auth/login` | Login user | No |
| GET | `/auth/me` | Get current user info | Yes |

#### POST /auth/register
```json
Request:
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}

Response (201):
{
  "message": "User registered successfully",
  "user": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "created_at": "2024-01-15T10:30:00"
  },
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

#### POST /auth/login
```json
Request:
{
  "email": "john@example.com",
  "password": "password123"
}

Response (200):
{
  "message": "Login successful",
  "user": { ... },
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

### Category Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/categories/` | Get all user categories | Yes |
| POST | `/categories/` | Create new category | Yes |
| PUT | `/categories/<id>` | Update category | Yes |
| DELETE | `/categories/<id>` | Delete category | Yes |

#### POST /categories/
```json
Request:
{
  "name": "Groceries",
  "type": "expense",
  "icon": "🛒",
  "color": "#FF5733"
}

Response (201):
{
  "message": "Category created successfully",
  "category": {
    "id": 1,
    "name": "Groceries",
    "type": "expense",
    "icon": "🛒",
    "color": "#FF5733",
    "created_at": "2024-01-15T10:30:00"
  }
}
```

### Transaction Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/transactions/` | Get transactions (with filters) | Yes |
| POST | `/transactions/` | Create transaction | Yes |
| PUT | `/transactions/<id>` | Update transaction | Yes |
| DELETE | `/transactions/<id>` | Delete transaction | Yes |

#### GET /transactions/
Query Parameters:
- `month` (optional): Filter by month (1-12)
- `year` (optional): Filter by year
- `category_id` (optional): Filter by category
- `type` (optional): Filter by type (income/expense)

#### POST /transactions/
```json
Request:
{
  "amount": 150.50,
  "type": "expense",
  "category_id": 1,
  "note": "Weekly groceries",
  "date": "2024-01-15"
}

Response (201):
{
  "message": "Transaction created successfully",
  "transaction": {
    "id": 1,
    "amount": "150.50",
    "type": "expense",
    "note": "Weekly groceries",
    "date": "2024-01-15",
    "category": {
      "id": 1,
      "name": "Groceries",
      "type": "expense",
      "icon": "🛒",
      "color": "#FF5733"
    },
    "created_at": "2024-01-15T10:30:00"
  }
}
```

### Budget Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/budgets/?month=1&year=2024` | Get budgets for month/year | Yes |
| POST | `/budgets/` | Create/update budget | Yes |
| DELETE | `/budgets/<id>` | Delete budget | Yes |

#### GET /budgets/?month=1&year=2024
```json
Response (200):
{
  "budgets": [
    {
      "id": 1,
      "category_id": 1,
      "amount_limit": "500.00",
      "month": 1,
      "year": 2024,
      "spent": "350.00",
      "remaining": "150.00",
      "percentage": 70.0,
      "created_at": "2024-01-01T00:00:00"
    }
  ]
}
```

#### POST /budgets/
```json
Request:
{
  "category_id": 1,
  "amount_limit": 500.00,
  "month": 1,
  "year": 2024
}

Response (201):
{
  "message": "Budget created successfully",
  "budget": { ... }
}
```

### Dashboard Endpoint

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/dashboard/` | Get dashboard analytics | Yes |

Query Parameters:
- `month` (optional): Defaults to current month
- `year` (optional): Defaults to current year

```json
Response (200):
{
  "month": 1,
  "year": 2024,
  "total_income": "5000.00",
  "total_expenses": "3500.00",
  "savings": "1500.00",
  "savings_rate": 30.0,
  "category_breakdown": [
    {
      "category_name": "Groceries",
      "category_color": "#FF5733",
      "total_spent": "1200.00"
    }
  ],
  "budget_status": [
    {
      "category_name": "Groceries",
      "limit": "500.00",
      "spent": "350.00",
      "percentage": 70.0,
      "status": "safe"
    }
  ],
  "recent_transactions": [
    {
      "id": 1,
      "amount": "150.50",
      "type": "expense",
      "category_name": "Groceries",
      "note": "Weekly groceries",
      "date": "2024-01-15"
    }
  ]
}
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer <access_token>
```

## Error Responses

### 400 Bad Request
```json
{
  "error": "Validation failed",
  "messages": {
    "email": ["Not a valid email address."],
    "password": ["Shorter than minimum length 6."]
  }
}
```

### 401 Unauthorized
```json
{
  "error": "Invalid email or password"
}
```

### 404 Not Found
```json
{
  "error": "Transaction not found"
}
```

### 409 Conflict
```json
{
  "error": "Email already registered"
}
```

### 500 Internal Server Error
```json
{
  "error": "Failed to create transaction",
  "message": "Detailed error message"
}
```

## Database Models

### User
- id (Integer, Primary Key)
- name (String, 100)
- email (String, 120, Unique)
- password (String, 256, Hashed)
- created_at (DateTime)

### Category
- id (Integer, Primary Key)
- user_id (Foreign Key → users.id)
- name (String, 50)
- type (String, 10) - 'income' or 'expense'
- icon (String, 10, Optional)
- color (String, 7, Optional)
- created_at (DateTime)
- **Unique constraint:** (user_id, name)

### Transaction
- id (Integer, Primary Key)
- user_id (Foreign Key → users.id)
- category_id (Foreign Key → categories.id)
- amount (Numeric, 10,2)
- type (String, 10) - 'income' or 'expense'
- note (String, 255, Optional)
- date (Date)
- created_at (DateTime)
- **Check constraint:** amount > 0

### Budget
- id (Integer, Primary Key)
- user_id (Foreign Key → users.id)
- category_id (Foreign Key → categories.id)
- amount_limit (Numeric, 10,2)
- month (Integer, 1-12)
- year (Integer)
- created_at (DateTime)
- **Unique constraint:** (user_id, category_id, month, year)
- **Check constraints:** month between 1-12, amount_limit > 0

## Testing

Run tests with pytest:

```bash
pytest
pytest --cov=app tests/  # With coverage
```

## Project Structure

```
backend/
├── app/
│   ├── __init__.py           # Flask app factory
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── category.py
│   │   ├── transaction.py
│   │   └── budget.py
│   ├── schemas/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── category.py
│   │   ├── transaction.py
│   │   └── budget.py
│   └── routes/
│       ├── __init__.py
│       ├── auth.py
│       ├── categories.py
│       ├── transactions.py
│       ├── budgets.py
│       └── dashboard.py
├── config.py                 # Configuration classes
├── requirements.txt          # Python dependencies
├── run.py                    # Application entry point
└── README.md                 # This file
```

## Security Notes

- Passwords are hashed using Werkzeug's security functions (pbkdf2:sha256)
- JWT tokens are used for authentication
- All routes check ownership (users can only access their own data)
- SQL injection protection via SQLAlchemy ORM
- Input validation via Marshmallow schemas

## Production Deployment

For production deployment:

1. Set `FLASK_ENV=production` in environment variables
2. Use a strong, random JWT_SECRET_KEY
3. Use a production-grade WSGI server (gunicorn, uWSGI)
4. Enable HTTPS/SSL
5. Set up proper database backups
6. Use environment variables for sensitive data
7. Enable CORS only for trusted domains

Example with Gunicorn:
```bash
gunicorn -w 4 -b 0.0.0.0:5000 run:app
```

## License

MIT License
