import React, { useState, useEffect } from 'react';
import { FiX } from 'react-icons/fi';
import api from '../services/api';
import { toast } from 'react-toastify';
import './BudgetModal.css';

const BudgetModal = ({ isOpen, onClose, onSuccess, budget, categories }) => {
  const currentDate = new Date();
  const [formData, setFormData] = useState({
    categoryId: '',
    amount: '',
    month: currentDate.getMonth() + 1,
    year: currentDate.getFullYear(),
  });
  const [loading, setLoading] = useState(false);
  const [expenseCategories, setExpenseCategories] = useState([]);

  useEffect(() => {
    if (categories) {
      setExpenseCategories(categories.filter((cat) => cat.type === 'expense'));
    }
  }, [categories]);

  useEffect(() => {
    if (budget) {
      setFormData({
        categoryId: budget.categoryId || budget.category?._id,
        amount: budget.amount,
        month: budget.month,
        year: budget.year,
      });
    }
  }, [budget]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (budget) {
        await api.put(`/budgets/${budget._id}`, formData);
        toast.success('Budget updated successfully');
      } else {
        await api.post('/budgets', formData);
        toast.success('Budget added successfully');
      }
      onSuccess();
      onClose();
    } catch (error) {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 1; i <= currentYear + 2; i++) {
    years.push(i);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{budget ? 'Edit Budget' : 'Add Budget'}</h2>
          <button className="modal-close" onClick={onClose}>
            <FiX />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-group">
            <label className="form-label">Category (Expense)</label>
            <select
              name="categoryId"
              className="form-select"
              value={formData.categoryId}
              onChange={handleChange}
              required
            >
              <option value="">Select category</option>
              {expenseCategories.map((cat) => (
                <option key={cat._id} value={cat._id}>
                  {cat.icon} {cat.name}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Budget Amount (₹)</label>
            <input
              type="number"
              name="amount"
              className="form-input"
              placeholder="Enter budget amount"
              value={formData.amount}
              onChange={handleChange}
              min="0"
              step="0.01"
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Month</label>
              <select
                name="month"
                className="form-select"
                value={formData.month}
                onChange={handleChange}
                required
              >
                {months.map((month, index) => (
                  <option key={month} value={index + 1}>
                    {month}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Year</label>
              <select
                name="year"
                className="form-select"
                value={formData.year}
                onChange={handleChange}
                required
              >
                {years.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? (
                <>
                  <span className="spinner"></span>
                  <span>Saving...</span>
                </>
              ) : (
                'Save'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BudgetModal;
