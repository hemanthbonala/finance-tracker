import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiHome, FiList, FiTag, FiTrendingUp } from 'react-icons/fi';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <nav className="sidebar-nav">
        <NavLink
          to="/"
          className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
        >
          <FiHome className="sidebar-icon" />
          <span>Dashboard</span>
        </NavLink>
        <NavLink
          to="/transactions"
          className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
        >
          <FiList className="sidebar-icon" />
          <span>Transactions</span>
        </NavLink>
        <NavLink
          to="/categories"
          className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
        >
          <FiTag className="sidebar-icon" />
          <span>Categories</span>
        </NavLink>
        <NavLink
          to="/budgets"
          className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
        >
          <FiTrendingUp className="sidebar-icon" />
          <span>Budgets</span>
        </NavLink>
      </nav>
    </aside>
  );
};

export default Sidebar;
