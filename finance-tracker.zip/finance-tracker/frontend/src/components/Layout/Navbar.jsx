import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FiHome, FiList, FiTag, FiTrendingUp, FiLogOut, FiMenu, FiX } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <FiTrendingUp className="navbar-logo-icon" />
          <span>Finance Tracker</span>
        </Link>

        <button className="navbar-toggle" onClick={toggleMobileMenu}>
          {isMobileMenuOpen ? <FiX /> : <FiMenu />}
        </button>

        <div className={`navbar-menu ${isMobileMenuOpen ? 'active' : ''}`}>
          <div className="navbar-links">
            <NavLink
              to="/"
              className={({ isActive }) => `navbar-link ${isActive ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              <FiHome />
              <span>Dashboard</span>
            </NavLink>
            <NavLink
              to="/transactions"
              className={({ isActive }) => `navbar-link ${isActive ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              <FiList />
              <span>Transactions</span>
            </NavLink>
            <NavLink
              to="/categories"
              className={({ isActive }) => `navbar-link ${isActive ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              <FiTag />
              <span>Categories</span>
            </NavLink>
            <NavLink
              to="/budgets"
              className={({ isActive }) => `navbar-link ${isActive ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              <FiTrendingUp />
              <span>Budgets</span>
            </NavLink>
          </div>

          <div className="navbar-user">
            <span className="navbar-username">{user?.name}</span>
            <button onClick={handleLogout} className="navbar-logout">
              <FiLogOut />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
