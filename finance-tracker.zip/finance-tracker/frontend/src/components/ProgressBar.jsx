import React from 'react';
import './ProgressBar.css';

const ProgressBar = ({ percentage, label }) => {
  const getColor = () => {
    if (percentage < 80) return 'var(--success)';
    if (percentage < 100) return 'var(--warning)';
    return 'var(--danger)';
  };

  const safePercentage = Math.min(Math.max(percentage, 0), 100);

  return (
    <div className="progress-bar-container">
      {label && (
        <div className="progress-bar-label">
          <span>{label}</span>
          <span className="progress-bar-percentage">{Math.round(percentage)}%</span>
        </div>
      )}
      <div className="progress-bar-track">
        <div
          className="progress-bar-fill"
          style={{
            width: `${safePercentage}%`,
            backgroundColor: getColor(),
          }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
