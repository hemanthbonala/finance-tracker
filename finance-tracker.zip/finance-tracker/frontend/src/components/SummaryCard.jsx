import React from 'react';
import './SummaryCard.css';

const SummaryCard = ({ title, amount, icon: Icon, color }) => {
  const formatAmount = (num) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(num);
  };

  return (
    <div className="summary-card" style={{ borderTopColor: color }}>
      <div className="summary-card-header">
        <div className="summary-card-icon" style={{ backgroundColor: `${color}15`, color }}>
          <Icon />
        </div>
        <h3 className="summary-card-title">{title}</h3>
      </div>
      <div className="summary-card-amount" style={{ color }}>
        {formatAmount(amount)}
      </div>
    </div>
  );
};

export default SummaryCard;
