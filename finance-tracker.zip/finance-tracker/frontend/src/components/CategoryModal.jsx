import React, { useState, useEffect } from 'react';
import { FiX } from 'react-icons/fi';
import api from '../services/api';
import { toast } from 'react-toastify';
import './CategoryModal.css';

const CategoryModal = ({ isOpen, onClose, onSuccess, category }) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'expense',
    icon: '📁',
    color: '#4F46E5',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (category) {
      setFormData({
        name: category.name,
        type: category.type,
        icon: category.icon || '📁',
        color: category.color || '#4F46E5',
      });
    }
  }, [category]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (category) {
        await api.put(`/categories/${category.id}`, formData);
        toast.success('Category updated successfully');
      } else {
        await api.post('/categories', formData);
        toast.success('Category added successfully');
      }
      onSuccess();
      onClose();
    } catch (error) {
      toast.error('Failed to save category');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{category ? 'Edit Category' : 'Add Category'}</h2>
          <button className="modal-close" onClick={onClose}>
            <FiX />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-group">
            <label className="form-label">Name</label>
            <input
              type="text"
              name="name"
              className="form-input"
              placeholder="Enter category name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Type</label>
            <select
              name="type"
              className="form-select"
              value={formData.type}
              onChange={handleChange}
              required
            >
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Icon (Emoji)</label>
            <input
              type="text"
              name="icon"
              className="form-input"
              placeholder="Enter emoji (e.g., 🍕)"
              value={formData.icon}
              onChange={handleChange}
              maxLength="2"
              required
            />
            <small className="form-hint">
              Use any emoji: 🍕 🚗 🏠 💰 🛒 📱 ⚡ 🎮 🎬 💼
            </small>
          </div>

          <div className="form-group">
            <label className="form-label">Color</label>
            <div className="color-picker-container">
              <input
                type="color"
                name="color"
                className="color-picker"
                value={formData.color}
                onChange={handleChange}
              />
              <input
                type="text"
                className="form-input"
                value={formData.color}
                onChange={handleChange}
                name="color"
                placeholder="#4F46E5"
                pattern="^#[0-9A-Fa-f]{6}$"
              />
            </div>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? (
                <>
                  <span className="spinner"></span>
                  <span>Saving...</span>
                </>
              ) : (
                'Save'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CategoryModal;
