import React, { useState, useEffect } from 'react';
import { FiTrendingUp, FiTrendingDown, FiDollarSign, FiPercent } from 'react-icons/fi';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { format } from 'date-fns';
import api from '../services/api';
import SummaryCard from '../components/SummaryCard';
import ProgressBar from '../components/ProgressBar';
import './Dashboard.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    fetchDashboardData();
  }, [selectedMonth, selectedYear]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/dashboard?month=${selectedMonth}&year=${selectedYear}`);
      setDashboardData(response.data);
    } catch (error) {
      setDashboardData(null);
    } finally {
      setLoading(false);
    }
  };

  const formatAmount = (num) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(num);
  };

  const formatDate = (dateString) => {
    return format(new Date(dateString), 'dd MMM yyyy');
  };

  const getCategoryChartData = () => {
    if (!dashboardData?.categoryBreakdown || dashboardData.categoryBreakdown.length === 0) {
      return null;
    }

    return {
      labels: dashboardData.categoryBreakdown.map((cat) => cat.name),
      datasets: [
        {
          data: dashboardData.categoryBreakdown.map((cat) => cat.total),
          backgroundColor: dashboardData.categoryBreakdown.map((cat) => cat.color || '#4F46E5'),
          borderWidth: 2,
          borderColor: '#fff',
        },
      ],
    };
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          padding: 15,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            const label = context.label || '';
            const value = formatAmount(context.parsed);
            return `${label}: ${value}`;
          },
        },
      },
    },
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 2; i <= currentYear + 1; i++) {
    years.push(i);
  }

  const chartData = getCategoryChartData();

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <div className="dashboard-filters">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="form-select"
          >
            {months.map((month, index) => (
              <option key={month} value={index + 1}>
                {month}
              </option>
            ))}
          </select>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="form-select"
          >
            {years.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="summary-cards">
        <SummaryCard
          title="Total Income"
          amount={dashboardData?.totalIncome || 0}
          icon={FiTrendingUp}
          color="var(--success)"
        />
        <SummaryCard
          title="Total Expenses"
          amount={dashboardData?.totalExpenses || 0}
          icon={FiTrendingDown}
          color="var(--danger)"
        />
        <SummaryCard
          title="Savings"
          amount={(dashboardData?.totalIncome || 0) - (dashboardData?.totalExpenses || 0)}
          icon={FiDollarSign}
          color="var(--info)"
        />
        <SummaryCard
          title="Savings Rate"
          amount={dashboardData?.savingsRate || 0}
          icon={FiPercent}
          color="var(--warning)"
        />
      </div>

      <div className="dashboard-content">
        <div className="dashboard-section">
          <div className="card">
            <h2>Expense Breakdown</h2>
            {chartData ? (
              <div className="chart-container">
                <Doughnut data={chartData} options={chartOptions} />
              </div>
            ) : (
              <p className="text-muted text-center">No expense data available</p>
            )}
          </div>
        </div>

        <div className="dashboard-section">
          <div className="card">
            <h2>Budget Status</h2>
            {dashboardData?.budgets && dashboardData.budgets.length > 0 ? (
              <div className="budget-list">
                {dashboardData.budgets.map((budget) => {
                  const percentage = (budget.spent / budget.amount) * 100;
                  return (
                    <div key={budget._id} className="budget-item">
                      <div className="budget-header">
                        <span className="budget-name">
                          {budget.category?.icon} {budget.category?.name}
                        </span>
                        <span className="budget-amount">
                          {formatAmount(budget.spent)} / {formatAmount(budget.amount)}
                        </span>
                      </div>
                      <ProgressBar percentage={percentage} />
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-muted text-center">No budgets set for this month</p>
            )}
          </div>
        </div>

        <div className="dashboard-section dashboard-section-full">
          <div className="card">
            <h2>Recent Transactions</h2>
            {dashboardData?.recentTransactions && dashboardData.recentTransactions.length > 0 ? (
              <div className="transactions-list">
                {dashboardData.recentTransactions.map((transaction) => (
                  <div key={transaction._id} className="transaction-item">
                    <div className="transaction-info">
                      <span className="transaction-icon">{transaction.category?.icon}</span>
                      <div>
                        <div className="transaction-note">{transaction.note || 'No note'}</div>
                        <div className="transaction-date">{formatDate(transaction.date)}</div>
                      </div>
                    </div>
                    <div className="transaction-details">
                      <span className={`badge badge-${transaction.type}`}>
                        {transaction.type}
                      </span>
                      <span className={`transaction-amount text-${transaction.type === 'income' ? 'success' : 'danger'}`}>
                        {transaction.type === 'income' ? '+' : '-'}
                        {formatAmount(transaction.amount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted text-center">No transactions found</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
