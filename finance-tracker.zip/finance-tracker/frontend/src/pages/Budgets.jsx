import React, { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import { toast } from 'react-toastify';
import api from '../services/api';
import BudgetModal from '../components/BudgetModal';
import ProgressBar from '../components/ProgressBar';
import './Budgets.css';

const Budgets = () => {
  const [budgets, setBudgets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchBudgets();
  }, [selectedMonth, selectedYear]);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      const data = response.data;
      setCategories(Array.isArray(data) ? data : (data.categories || []));
    } catch (error) {
      setCategories([]);
    }
  };

  const fetchBudgets = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/budgets?month=${selectedMonth}&year=${selectedYear}`);
      const data = response.data;
      setBudgets(Array.isArray(data) ? data : (data.budgets || []));
    } catch (error) {
      setBudgets([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddClick = () => {
    setEditingBudget(null);
    setIsModalOpen(true);
  };

  const handleEditClick = (budget) => {
    setEditingBudget(budget);
    setIsModalOpen(true);
  };

  const handleDeleteClick = async (id) => {
    if (window.confirm('Are you sure you want to delete this budget?')) {
      try {
        await api.delete(`/budgets/${id}`);
        toast.success('Budget deleted successfully');
        fetchBudgets();
      } catch (error) {
        toast.error('Failed to delete budget');
      }
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingBudget(null);
  };

  const handleModalSuccess = () => {
    fetchBudgets();
  };

  const formatAmount = (num) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getStatusClass = (percentage) => {
    if (percentage < 80) return 'status-safe';
    if (percentage < 100) return 'status-warning';
    return 'status-over';
  };

  const totalBudget = budgets.reduce((sum, b) => sum + parseFloat(b.amount_limit || 0), 0);
  const totalSpent = budgets.reduce((sum, b) => sum + parseFloat(b.spent || 0), 0);
  const overallPercentage = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 1; i <= currentYear + 2; i++) {
    years.push(i);
  }

  return (
    <div className="budgets-page">
      <div className="page-header">
        <h1>Budgets</h1>
        <div className="header-actions">
          <div className="month-year-selector">
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="form-select"
            >
              {months.map((month, index) => (
                <option key={month} value={index + 1}>
                  {month}
                </option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="form-select"
            >
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleAddClick}>
            <FiPlus />
            <span>Add Budget</span>
          </button>
        </div>
      </div>

      {budgets.length > 0 && (
        <div className="card total-budget-card">
          <h2>Total Budget Summary</h2>
          <div className="total-budget-content">
            <div className="total-budget-amounts">
              <div className="total-budget-item">
                <span className="total-budget-label">Total Budget</span>
                <span className="total-budget-value">{formatAmount(totalBudget)}</span>
              </div>
              <div className="total-budget-item">
                <span className="total-budget-label">Total Spent</span>
                <span className="total-budget-value text-danger">{formatAmount(totalSpent)}</span>
              </div>
              <div className="total-budget-item">
                <span className="total-budget-label">Remaining</span>
                <span className={`total-budget-value ${totalBudget - totalSpent < 0 ? 'text-danger' : 'text-success'}`}>
                  {formatAmount(totalBudget - totalSpent)}
                </span>
              </div>
            </div>
            <ProgressBar percentage={overallPercentage} />
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
        </div>
      ) : budgets.length > 0 ? (
        <div className="budgets-grid">
          {budgets.map((budget) => {
            const percentage = (parseFloat(budget.spent || 0) / parseFloat(budget.amount_limit || 1)) * 100;
            return (
              <div key={budget.id} className={`budget-card ${getStatusClass(percentage)}`}>
                <div className="budget-card-header">
                  <div className="budget-category">
                    <span className="budget-icon">{budget.category?.icon}</span>
                    <h3>{budget.category?.name}</h3>
                  </div>
                  <div className="budget-card-actions">
                    <button
                      className="btn btn-sm btn-secondary"
                      onClick={() => handleEditClick(budget)}
                    >
                      <FiEdit2 />
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDeleteClick(budget.id)}
                    >
                      <FiTrash2 />
                    </button>
                  </div>
                </div>

                <div className="budget-amounts">
                  <div className="budget-amount-item">
                    <span className="budget-amount-label">Spent</span>
                    <span className="budget-amount-value text-danger">
                      {formatAmount(budget.spent)}
                    </span>
                  </div>
                  <div className="budget-amount-item">
                    <span className="budget-amount-label">Budget</span>
                    <span className="budget-amount-value">{formatAmount(parseFloat(budget.amount_limit || 0))}</span>
                  </div>
                  <div className="budget-amount-item">
                    <span className="budget-amount-label">Remaining</span>
                    <span className={`budget-amount-value ${parseFloat(budget.amount_limit || 0) - parseFloat(budget.spent || 0) < 0 ? 'text-danger' : 'text-success'}`}>
                      {formatAmount(parseFloat(budget.amount_limit || 0) - parseFloat(budget.spent || 0))}
                    </span>
                  </div>
                </div>

                <ProgressBar percentage={percentage} />

                <div className="budget-status">
                  {percentage < 80 && (
                    <span className="status-text status-text-safe">
                      Under budget - {Math.round(100 - percentage)}% remaining
                    </span>
                  )}
                  {percentage >= 80 && percentage < 100 && (
                    <span className="status-text status-text-warning">
                      Warning - {Math.round(100 - percentage)}% remaining
                    </span>
                  )}
                  {percentage >= 100 && (
                    <span className="status-text status-text-over">
                      Over budget by {Math.round(percentage - 100)}%
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="card">
          <p className="text-muted text-center">No budgets set for this month</p>
        </div>
      )}

      <BudgetModal
        isOpen={isModalOpen}
        onClose={handleModalClose}
        onSuccess={handleModalSuccess}
        budget={editingBudget}
        categories={categories}
      />
    </div>
  );
};

export default Budgets;
