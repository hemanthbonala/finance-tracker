import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FiTrendingUp, FiPieChart, FiTarget, FiShield } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import './Landing.css';

const Landing = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  return (
    <div className="landing">
      <nav className="landing-nav">
        <div className="landing-nav-brand">
          <FiTrendingUp className="landing-nav-icon" />
          <span className="landing-nav-title">Finance Tracker</span>
        </div>
        <div className="landing-nav-actions">
          {isAuthenticated ? (
            <button className="btn btn-primary" onClick={() => navigate('/dashboard')}>
              Go to Dashboard
            </button>
          ) : (
            <>
              <button className="btn btn-secondary" onClick={() => navigate('/login')}>
                Sign In
              </button>
              <button className="btn btn-primary" onClick={() => navigate('/register')}>
                Get Started
              </button>
            </>
          )}
        </div>
      </nav>

      <section className="landing-hero">
        <div className="hero-content">
          <h1 className="hero-title">
            Take Control of
            <br />
            <span className="hero-highlight">Your Finances</span>
          </h1>
          <p className="hero-description">
            Track your income and expenses, set monthly budgets, and see exactly where your money goes — all in one clean, simple dashboard.
          </p>
          <div className="hero-actions">
            <button className="btn btn-hero" onClick={() => navigate('/register')}>
              Start Tracking — Free
            </button>
            <p className="hero-note">No credit card needed. 100% free.</p>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-mockup">
            <div className="mockup-header">
              <span className="mockup-dot red"></span>
              <span className="mockup-dot yellow"></span>
              <span className="mockup-dot green"></span>
            </div>
            <div className="mockup-body">
              <div className="mockup-summary">
                <div className="mockup-card income">
                  <span className="mockup-label">Income</span>
                  <span className="mockup-amount">₹55,000</span>
                </div>
                <div className="mockup-card expense">
                  <span className="mockup-label">Expenses</span>
                  <span className="mockup-amount">₹32,000</span>
                </div>
                <div className="mockup-card savings">
                  <span className="mockup-label">Savings</span>
                  <span className="mockup-amount">₹23,000</span>
                </div>
              </div>
              <div className="mockup-budget">
                <div className="mockup-budget-item">
                  <span>🍕 Food</span>
                  <div className="mockup-bar"><div className="mockup-fill" style={{width: '65%'}}></div></div>
                  <span>₹5,200/₹8,000</span>
                </div>
                <div className="mockup-budget-item">
                  <span>🛒 Shopping</span>
                  <div className="mockup-bar"><div className="mockup-fill warning" style={{width: '92%'}}></div></div>
                  <span>₹4,600/₹5,000</span>
                </div>
                <div className="mockup-budget-item">
                  <span>🏠 Rent</span>
                  <div className="mockup-bar"><div className="mockup-fill" style={{width: '100%'}}></div></div>
                  <span>₹15,000/₹15,000</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="landing-features">
        <h2 className="features-title">Everything you need to manage your money</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon"><FiTrendingUp size={32} /></div>
            <h3>Track Income and Expenses</h3>
            <p>Add every transaction with categories, notes, and dates. Know exactly where each rupee goes.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon"><FiPieChart size={32} /></div>
            <h3>Visual Breakdown</h3>
            <p>See your spending patterns with charts. Identify where you overspend at a glance.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon"><FiTarget size={32} /></div>
            <h3>Set Budgets</h3>
            <p>Set monthly limits per category. Get warnings when you are close to your budget.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon"><FiShield size={32} /></div>
            <h3>Secure and Private</h3>
            <p>Your data is yours. JWT authentication, encrypted storage, no third-party sharing.</p>
          </div>
        </div>
      </section>

      <section className="landing-cta">
        <h2>Ready to take control?</h2>
        <p>Join thousands of users managing their finances better every day.</p>
        <button className="btn btn-hero" onClick={() => navigate('/register')}>
          Create Free Account
        </button>
      </section>

      <footer className="landing-footer">
        <p>Built with Flask, React, and PostgreSQL</p>
      </footer>
    </div>
  );
};

export default Landing;
