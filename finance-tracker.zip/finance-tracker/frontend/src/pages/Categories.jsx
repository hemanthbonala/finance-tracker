import React, { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import { toast } from 'react-toastify';
import api from '../services/api';
import CategoryModal from '../components/CategoryModal';
import './Categories.css';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const response = await api.get('/categories');
      const data = response.data;
      setCategories(Array.isArray(data) ? data : (data.categories || []));
    } catch (error) {
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddClick = () => {
    setEditingCategory(null);
    setIsModalOpen(true);
  };

  const handleEditClick = (category) => {
    setEditingCategory(category);
    setIsModalOpen(true);
  };

  const handleDeleteClick = async (id) => {
    if (
      window.confirm(
        'Are you sure you want to delete this category? This will affect related transactions and budgets.'
      )
    ) {
      try {
        await api.delete(`/categories/${id}`);
        toast.success('Category deleted successfully');
        fetchCategories();
      } catch (error) {
        toast.error('Failed to delete category');
      }
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingCategory(null);
  };

  const handleModalSuccess = () => {
    fetchCategories();
  };

  const incomeCategories = categories.filter((cat) => cat.type === 'income');
  const expenseCategories = categories.filter((cat) => cat.type === 'expense');

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  return (
    <div className="categories-page">
      <div className="page-header">
        <h1>Categories</h1>
        <button className="btn btn-primary" onClick={handleAddClick}>
          <FiPlus />
          <span>Add Category</span>
        </button>
      </div>

      <div className="categories-sections">
        <div className="categories-section">
          <div className="section-header">
            <h2>Income Categories</h2>
            <span className="section-count">{incomeCategories.length}</span>
          </div>
          {incomeCategories.length > 0 ? (
            <div className="categories-grid">
              {incomeCategories.map((category) => (
                <div
                  key={category.id}
                  className="category-card"
                  style={{ borderTopColor: category.color }}
                >
                  <div className="category-card-header">
                    <span className="category-icon" style={{ color: category.color }}>
                      {category.icon}
                    </span>
                    <span className={`badge badge-${category.type}`}>{category.type}</span>
                  </div>
                  <h3 className="category-name">{category.name}</h3>
                  <div className="category-actions">
                    <button
                      className="btn btn-sm btn-secondary"
                      onClick={() => handleEditClick(category)}
                    >
                      <FiEdit2 />
                      <span>Edit</span>
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDeleteClick(category.id)}
                    >
                      <FiTrash2 />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted text-center">No income categories found</p>
          )}
        </div>

        <div className="categories-section">
          <div className="section-header">
            <h2>Expense Categories</h2>
            <span className="section-count">{expenseCategories.length}</span>
          </div>
          {expenseCategories.length > 0 ? (
            <div className="categories-grid">
              {expenseCategories.map((category) => (
                <div
                  key={category.id}
                  className="category-card"
                  style={{ borderTopColor: category.color }}
                >
                  <div className="category-card-header">
                    <span className="category-icon" style={{ color: category.color }}>
                      {category.icon}
                    </span>
                    <span className={`badge badge-${category.type}`}>{category.type}</span>
                  </div>
                  <h3 className="category-name">{category.name}</h3>
                  <div className="category-actions">
                    <button
                      className="btn btn-sm btn-secondary"
                      onClick={() => handleEditClick(category)}
                    >
                      <FiEdit2 />
                      <span>Edit</span>
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDeleteClick(category.id)}
                    >
                      <FiTrash2 />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted text-center">No expense categories found</p>
          )}
        </div>
      </div>

      <CategoryModal
        isOpen={isModalOpen}
        onClose={handleModalClose}
        onSuccess={handleModalSuccess}
        category={editingCategory}
      />
    </div>
  );
};

export default Categories;
